<?php
/**
 * @package 	WordPress
 * @subpackage 	Dream City
 * @version 	1.0.0
 * 
 * Theme Content Composer Shortcodes
 * Created by CMSMasters
 * 
 */

