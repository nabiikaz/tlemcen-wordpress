/**
 * @package 	WordPress
 * @subpackage 	Dream City
 * @version		1.0.0
 * 
 * Script for Widgets in Admin Panel
 * Created by CMSMasters
 * 
 */

